﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.medicationTextBox = new System.Windows.Forms.TextBox();
            this.surgicalTextBox = new System.Windows.Forms.TextBox();
            this.labTextBox = new System.Windows.Forms.TextBox();
            this.physicalTextBox = new System.Windows.Forms.TextBox();
            this.daysLabel = new System.Windows.Forms.Label();
            this.medicationLabel = new System.Windows.Forms.Label();
            this.surgicalLabel = new System.Windows.Forms.Label();
            this.labLabel = new System.Windows.Forms.Label();
            this.physicalLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(183, 62);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysTextBox.TabIndex = 0;
            // 
            // medicationTextBox
            // 
            this.medicationTextBox.Location = new System.Drawing.Point(183, 88);
            this.medicationTextBox.Name = "medicationTextBox";
            this.medicationTextBox.Size = new System.Drawing.Size(100, 20);
            this.medicationTextBox.TabIndex = 1;
            // 
            // surgicalTextBox
            // 
            this.surgicalTextBox.Location = new System.Drawing.Point(183, 114);
            this.surgicalTextBox.Name = "surgicalTextBox";
            this.surgicalTextBox.Size = new System.Drawing.Size(100, 20);
            this.surgicalTextBox.TabIndex = 2;
            // 
            // labTextBox
            // 
            this.labTextBox.Location = new System.Drawing.Point(183, 140);
            this.labTextBox.Name = "labTextBox";
            this.labTextBox.Size = new System.Drawing.Size(100, 20);
            this.labTextBox.TabIndex = 3;
            // 
            // physicalTextBox
            // 
            this.physicalTextBox.Location = new System.Drawing.Point(183, 166);
            this.physicalTextBox.Name = "physicalTextBox";
            this.physicalTextBox.Size = new System.Drawing.Size(100, 20);
            this.physicalTextBox.TabIndex = 4;
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(95, 65);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(82, 13);
            this.daysLabel.TabIndex = 5;
            this.daysLabel.Text = "Days at hospital";
            // 
            // medicationLabel
            // 
            this.medicationLabel.AutoSize = true;
            this.medicationLabel.Location = new System.Drawing.Point(77, 91);
            this.medicationLabel.Name = "medicationLabel";
            this.medicationLabel.Size = new System.Drawing.Size(100, 13);
            this.medicationLabel.TabIndex = 6;
            this.medicationLabel.Text = "Medication charges";
            // 
            // surgicalLabel
            // 
            this.surgicalLabel.AutoSize = true;
            this.surgicalLabel.Location = new System.Drawing.Point(109, 117);
            this.surgicalLabel.Name = "surgicalLabel";
            this.surgicalLabel.Size = new System.Drawing.Size(68, 13);
            this.surgicalLabel.TabIndex = 7;
            this.surgicalLabel.Text = "Surgical fees";
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Location = new System.Drawing.Point(129, 143);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(48, 13);
            this.labLabel.TabIndex = 8;
            this.labLabel.Text = "Lab fees";
            // 
            // physicalLabel
            // 
            this.physicalLabel.AutoSize = true;
            this.physicalLabel.Location = new System.Drawing.Point(78, 169);
            this.physicalLabel.Name = "physicalLabel";
            this.physicalLabel.Size = new System.Drawing.Size(99, 13);
            this.physicalLabel.TabIndex = 9;
            this.physicalLabel.Text = "Physical rehab cost";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(282, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(37, 227);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 11;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Please fill in this form to calculate your total costs";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 303);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.physicalLabel);
            this.Controls.Add(this.labLabel);
            this.Controls.Add(this.surgicalLabel);
            this.Controls.Add(this.medicationLabel);
            this.Controls.Add(this.daysLabel);
            this.Controls.Add(this.physicalTextBox);
            this.Controls.Add(this.labTextBox);
            this.Controls.Add(this.surgicalTextBox);
            this.Controls.Add(this.medicationTextBox);
            this.Controls.Add(this.daysTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.TextBox medicationTextBox;
        private System.Windows.Forms.TextBox surgicalTextBox;
        private System.Windows.Forms.TextBox labTextBox;
        private System.Windows.Forms.TextBox physicalTextBox;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label medicationLabel;
        private System.Windows.Forms.Label surgicalLabel;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.Label physicalLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label label1;
    }
}

