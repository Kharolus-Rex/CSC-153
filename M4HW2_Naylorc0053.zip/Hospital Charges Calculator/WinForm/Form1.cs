﻿/**
* 3/22/23
* CSC 153
* Connor Naylor
* This program will calculate the total cost of a hospital visit.
* Methods will calculate cost of your total days spent there,
* the total of other fees, and then your final total.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int days;
            double medFees, surgFees, labFees, physFees;
            double dayCharge, miscCharge, totalCharge;

            days = int.Parse(daysTextBox.Text);
            medFees = double.Parse(medicationTextBox.Text);
            surgFees = double.Parse(surgicalTextBox.Text);
            labFees = double.Parse(labTextBox.Text);
            physFees = double.Parse(physicalTextBox.Text);

            dayCharge = chargeCalculations.calcStayCharges(days);

            miscCharge = chargeCalculations.calcMiscCharges(medFees, surgFees, labFees, physFees);

            totalCharge = chargeCalculations.calcTotalCharges(dayCharge, miscCharge);

            MessageBox.Show("Your total daily charge: " + dayCharge + "\nYour total misc charges: " + miscCharge + "\nYour total charges: " + totalCharge);
        }
    }
}
