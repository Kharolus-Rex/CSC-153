﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    class chargeCalculations
    {
        public static double calcStayCharges(int days)
        {
            double stayCharge = 0.0;

            stayCharge = 350.0 * days;

            return stayCharge;
        }

        public static double calcMiscCharges(double medFees, double surgFees, double labFees, double physFees)
        {
            double miscCharges = 0.0 + medFees + surgFees + labFees + physFees;

            return miscCharges;
        }

        public static double calcTotalCharges(double stayCharges, double miscCharges)
        {
            double totalCharges = stayCharges + miscCharges;

            return totalCharges;
        }
    }
}
