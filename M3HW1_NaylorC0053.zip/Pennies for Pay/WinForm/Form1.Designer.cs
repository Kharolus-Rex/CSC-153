﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.daysWorkLabel = new System.Windows.Forms.Label();
            this.daysWorkTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.incomeLabel = new System.Windows.Forms.Label();
            this.totalIncomeOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(206, 140);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // daysWorkLabel
            // 
            this.daysWorkLabel.AutoSize = true;
            this.daysWorkLabel.Location = new System.Drawing.Point(109, 72);
            this.daysWorkLabel.Name = "daysWorkLabel";
            this.daysWorkLabel.Size = new System.Drawing.Size(72, 13);
            this.daysWorkLabel.TabIndex = 1;
            this.daysWorkLabel.Text = "Days to Work";
            // 
            // daysWorkTextBox
            // 
            this.daysWorkTextBox.Location = new System.Drawing.Point(206, 69);
            this.daysWorkTextBox.Name = "daysWorkTextBox";
            this.daysWorkTextBox.Size = new System.Drawing.Size(75, 20);
            this.daysWorkTextBox.TabIndex = 2;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(106, 140);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.Location = new System.Drawing.Point(103, 16);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(195, 48);
            this.instructionsLabel.TabIndex = 4;
            this.instructionsLabel.Text = "Please input a number of days to work to calculate income in pennies per day, inc" +
    "reasing by X2 per day.";
            // 
            // incomeLabel
            // 
            this.incomeLabel.AutoSize = true;
            this.incomeLabel.Location = new System.Drawing.Point(109, 102);
            this.incomeLabel.Name = "incomeLabel";
            this.incomeLabel.Size = new System.Drawing.Size(69, 13);
            this.incomeLabel.TabIndex = 5;
            this.incomeLabel.Text = "Total Income";
            // 
            // totalIncomeOutputLabel
            // 
            this.totalIncomeOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalIncomeOutputLabel.Location = new System.Drawing.Point(206, 101);
            this.totalIncomeOutputLabel.Name = "totalIncomeOutputLabel";
            this.totalIncomeOutputLabel.Size = new System.Drawing.Size(75, 20);
            this.totalIncomeOutputLabel.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 219);
            this.Controls.Add(this.totalIncomeOutputLabel);
            this.Controls.Add(this.incomeLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.daysWorkTextBox);
            this.Controls.Add(this.daysWorkLabel);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label daysWorkLabel;
        private System.Windows.Forms.TextBox daysWorkTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label incomeLabel;
        private System.Windows.Forms.Label totalIncomeOutputLabel;
    }
}

