﻿/**
* 2/27/23
* CSC 153
* Connor Naylor
* This is to calculate income in pennies
* Increasing exponentially by X2 per day worked.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int pennies = 1;
            int totalPay = 0;
            int days = int.Parse(daysWorkTextBox.Text);

            for (int i = 1; i <= days; i++)
            {
                totalPay += pennies;
                pennies *= 2;
            }
            totalIncomeOutputLabel.Text = totalPay.ToString("c");
        }
    }
}
