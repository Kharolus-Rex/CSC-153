﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.propertyValueLabel = new System.Windows.Forms.Label();
            this.propertyValueTextBox = new System.Windows.Forms.TextBox();
            this.calculateTaxButton = new System.Windows.Forms.Button();
            this.exitFormButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // propertyValueLabel
            // 
            this.propertyValueLabel.AutoSize = true;
            this.propertyValueLabel.Location = new System.Drawing.Point(69, 34);
            this.propertyValueLabel.Name = "propertyValueLabel";
            this.propertyValueLabel.Size = new System.Drawing.Size(76, 13);
            this.propertyValueLabel.TabIndex = 0;
            this.propertyValueLabel.Text = "Property Value";
            this.propertyValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // propertyValueTextBox
            // 
            this.propertyValueTextBox.Location = new System.Drawing.Point(151, 31);
            this.propertyValueTextBox.Name = "propertyValueTextBox";
            this.propertyValueTextBox.Size = new System.Drawing.Size(100, 20);
            this.propertyValueTextBox.TabIndex = 1;
            // 
            // calculateTaxButton
            // 
            this.calculateTaxButton.Location = new System.Drawing.Point(40, 81);
            this.calculateTaxButton.Name = "calculateTaxButton";
            this.calculateTaxButton.Size = new System.Drawing.Size(82, 37);
            this.calculateTaxButton.TabIndex = 2;
            this.calculateTaxButton.Text = "Calculate Property Tax";
            this.calculateTaxButton.UseVisualStyleBackColor = true;
            this.calculateTaxButton.Click += new System.EventHandler(this.calculateTaxButton_Click);
            // 
            // exitFormButton
            // 
            this.exitFormButton.Location = new System.Drawing.Point(190, 81);
            this.exitFormButton.Name = "exitFormButton";
            this.exitFormButton.Size = new System.Drawing.Size(82, 37);
            this.exitFormButton.TabIndex = 3;
            this.exitFormButton.Text = "Exit";
            this.exitFormButton.UseVisualStyleBackColor = true;
            this.exitFormButton.Click += new System.EventHandler(this.exitFormButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 177);
            this.Controls.Add(this.exitFormButton);
            this.Controls.Add(this.calculateTaxButton);
            this.Controls.Add(this.propertyValueTextBox);
            this.Controls.Add(this.propertyValueLabel);
            this.Name = "Form1";
            this.Text = "Property Tax Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label propertyValueLabel;
        private System.Windows.Forms.TextBox propertyValueTextBox;
        private System.Windows.Forms.Button calculateTaxButton;
        private System.Windows.Forms.Button exitFormButton;
    }
}

