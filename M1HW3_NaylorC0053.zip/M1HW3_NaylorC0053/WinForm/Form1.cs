﻿/**
 * 1/25/23
 * CSC 153
 * Connor Naylor
 * This program is designed to
 * calculate property tax given the
 * input of the property value 
 * from the user
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateTaxButton_Click(object sender, EventArgs e)
        {

            MessageBox.Show((double.Parse(propertyValueTextBox.Text) / 100 * 0.64).ToString("c"));

        }

        private void exitFormButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
