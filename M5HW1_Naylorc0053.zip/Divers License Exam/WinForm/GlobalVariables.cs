﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    public static class GlobalVariables
    {
        //init vars
        public static int probRight, probWrong;
        public static List<int> wrongQuestions = new List<int>();

        //init array for answer key and user answers
        public static char[] answerKey = { 'B', 'D', 'A', 'A', 'C', 'A', 'D', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A' };
        public static char[] userKey = new char[20];

        public static string wQuestions;

        public static void WrongQuestionFill()
        {
            //I learned how to string concatenate a week or so ago, pog
            //it has to go here because the list isn't filled out until later
            wQuestions = string.Join(", ", wrongQuestions);
        }
    }
}
