﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    class Results
    {
        public static void DsiplayResults()
        {
            //if statement to determine right or wrong
            string response;

            if (GlobalVariables.probRight >= 15)
            {
                response = "\nYou passed!";
            }
            else
            {
                response = "\nYou did not pass. Try again later.";
            }

            MessageBox.Show("Number of correct answers: " + GlobalVariables.probRight + "\nNumber of incorrect answers: " + GlobalVariables.probWrong + "\nQuestions answered incorrectly: " + GlobalVariables.wQuestions + response);
        }
    }
}
