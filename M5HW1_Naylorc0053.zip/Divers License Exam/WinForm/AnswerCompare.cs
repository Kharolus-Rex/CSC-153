﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    class AnswerCompare
    {
        public static void CompareAnswers()
        {
            //loop var
            int i;

            for (i = 0; i < GlobalVariables.answerKey.Length; i++)
            {
                if (GlobalVariables.userKey[i] == GlobalVariables.answerKey[i])
                {
                    GlobalVariables.probRight++;
                }
                else
                {
                    GlobalVariables.probWrong++;
                    GlobalVariables.wrongQuestions.Add(i);
                }
            }
        }
    }
}
