﻿/**
* 4-5-23
* CSC 153
* Connor Naylor
* This program will take a text file, with one letter answers per line
* and compare it to the pre-set answer key to determine if the exam taker
* passed or failed the exam. It will also inform the user of how many
* questions were right, wrong, and what questions they got wrong.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //all other variables, including list/array are in GlobalVariables class library
            int i = 0, j = 0;

            StreamReader inputFile; //file to be read for answers

            openFileDialog1.ShowDialog(); //get file

            inputFile = File.OpenText(openFileDialog1.FileName);

            while (!inputFile.EndOfStream)
            {
                GlobalVariables.userKey[i] = char.Parse(inputFile.ReadLine());

                i++;
            }

            //comparison loop
            //AnswerCompare
            AnswerCompare.CompareAnswers();

            //Display results
            //this is used to turn the list tracking wrong questions into a concatenated string
            GlobalVariables.WrongQuestionFill();
            Results.DsiplayResults();
        }
    }
}
