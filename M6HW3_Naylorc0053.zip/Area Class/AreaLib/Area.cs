﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaLib
{
    public class Area
    {

        public static double CalcArea(double radius)
        {
            //circle calc
            return Math.PI * Math.Pow(radius, 2);
        }

        public static double CalcArea(double radius, double height)
        {
            //cylinder calc
            return Math.PI * Math.Pow(radius, 2) * height;
        }

        public static double CalcArea(int width, int length)
        {
            //rectangle calc
            return width * length;
        }

    }
}
