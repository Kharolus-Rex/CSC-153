﻿/**
* 5/3/23
* CSC 153
* Connor Naylor
* This program is to demonstrate my understanding of overloaded methods.
* 3 methods share a name, and C# will choose the correct one based on 
* the input for the method.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AreaLib;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The area of this circle is " + Area.CalcArea(4.5).ToString("F3"));
        }

        private void rectangleButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The area of this rectangle is " + Area.CalcArea(8.2, 4.5).ToString("F3"));
        }

        private void cylinderButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The area of this cylinder is " + Area.CalcArea(9, 7));
        }
    }
}
