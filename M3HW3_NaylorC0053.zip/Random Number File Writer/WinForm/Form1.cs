﻿/**
* 3/9/23
* CSC-153
* Connor Naylor
* A program designed to write random numbers to a text file.
* How many numbers are written is determined by input from the user.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            StreamWriter outputFile;

            saveFileDialog.ShowDialog();
            
            //set output file
            outputFile = File.CreateText(saveFileDialog.FileName);

            //write to file
            int number;
            int numToWrite = int.Parse(numbersToWrite.Text);
            int i; 

            for (i = 1; i <= numToWrite; i++)
            {
                number = rand.Next(1, 101);
                outputFile.WriteLine(number);
            }
            //close file
            outputFile.Close();

            //notify user
            MessageBox.Show(numToWrite + " random numbers have been written to your file.");


        }
    }
}
