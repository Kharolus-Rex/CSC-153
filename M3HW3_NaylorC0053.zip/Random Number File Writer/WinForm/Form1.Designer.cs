﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.numbersToWrite = new System.Windows.Forms.TextBox();
            this.numbersToWriteLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // numbersToWrite
            // 
            this.numbersToWrite.Location = new System.Drawing.Point(211, 74);
            this.numbersToWrite.Name = "numbersToWrite";
            this.numbersToWrite.Size = new System.Drawing.Size(100, 20);
            this.numbersToWrite.TabIndex = 0;
            // 
            // numbersToWriteLabel
            // 
            this.numbersToWriteLabel.AutoSize = true;
            this.numbersToWriteLabel.Location = new System.Drawing.Point(91, 37);
            this.numbersToWriteLabel.Name = "numbersToWriteLabel";
            this.numbersToWriteLabel.Size = new System.Drawing.Size(349, 13);
            this.numbersToWriteLabel.TabIndex = 1;
            this.numbersToWriteLabel.Text = "Please enter the amount of random numbers you want to write to your file";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(94, 130);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save As";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(365, 130);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 3;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 193);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.numbersToWriteLabel);
            this.Controls.Add(this.numbersToWrite);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.TextBox numbersToWrite;
        private System.Windows.Forms.Label numbersToWriteLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
    }
}

