﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WinForm
{
    class dataReader
    {
        
        public static List<string> TeamsReader(String filePath)
        {
            List<string> teams = new List<string>();

            StreamReader reader = new StreamReader(filePath);

            while (!reader.EndOfStream)
            {
                teams.Add(reader.ReadLine());
            }

            return teams;

        }

        public static List<string> WinnerReader(String filePath)
        {
            List<string> winners = new List<string>();

            StreamReader reader = new StreamReader(filePath);

            while (!reader.EndOfStream)
            {
                winners.Add(reader.ReadLine());
            }

            return winners;
        }

        //I'll just throw the for loop in here as well. It's all data reading anyways.
        public static int GetNumberOfWins(String team, List<string> worldSeriesWinners)
        {
            int wins = 0;

            for (int i=0; i < worldSeriesWinners.Count; i++)
            {
                if (worldSeriesWinners[i] == team)
                {
                    wins++;
                }
            }

            return wins;
        }
    }
}
