﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    class CalculationClass
    {
        public static double FallingDistance(double seconds)
        {
            //init variables
            double time = seconds;
            double gravity = 9.8;
            double distance;
            double half = 0.5;

            //calculate
            distance = half * (gravity * Math.Pow(time, 2));

            //return
            return distance;
        }
    }
}
