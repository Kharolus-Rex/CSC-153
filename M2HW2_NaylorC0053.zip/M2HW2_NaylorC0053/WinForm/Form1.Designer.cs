﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.penniesTextBox = new System.Windows.Forms.TextBox();
            this.penniesLabel = new System.Windows.Forms.Label();
            this.nickelsLabel = new System.Windows.Forms.Label();
            this.dimesLabel = new System.Windows.Forms.Label();
            this.nickelsTextBox = new System.Windows.Forms.TextBox();
            this.dimesTextBox = new System.Windows.Forms.TextBox();
            this.quartersTextBox = new System.Windows.Forms.TextBox();
            this.quartersLabel = new System.Windows.Forms.Label();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.dollarLabel = new System.Windows.Forms.Label();
            this.submitAnswerButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // penniesTextBox
            // 
            this.penniesTextBox.Location = new System.Drawing.Point(114, 69);
            this.penniesTextBox.Name = "penniesTextBox";
            this.penniesTextBox.Size = new System.Drawing.Size(73, 20);
            this.penniesTextBox.TabIndex = 0;
            // 
            // penniesLabel
            // 
            this.penniesLabel.AutoSize = true;
            this.penniesLabel.Location = new System.Drawing.Point(63, 72);
            this.penniesLabel.Name = "penniesLabel";
            this.penniesLabel.Size = new System.Drawing.Size(45, 13);
            this.penniesLabel.TabIndex = 1;
            this.penniesLabel.Text = "Pennies";
            // 
            // nickelsLabel
            // 
            this.nickelsLabel.AutoSize = true;
            this.nickelsLabel.Location = new System.Drawing.Point(66, 107);
            this.nickelsLabel.Name = "nickelsLabel";
            this.nickelsLabel.Size = new System.Drawing.Size(42, 13);
            this.nickelsLabel.TabIndex = 2;
            this.nickelsLabel.Text = "Nickels";
            // 
            // dimesLabel
            // 
            this.dimesLabel.AutoSize = true;
            this.dimesLabel.Location = new System.Drawing.Point(72, 144);
            this.dimesLabel.Name = "dimesLabel";
            this.dimesLabel.Size = new System.Drawing.Size(36, 13);
            this.dimesLabel.TabIndex = 3;
            this.dimesLabel.Text = "Dimes";
            // 
            // nickelsTextBox
            // 
            this.nickelsTextBox.Location = new System.Drawing.Point(114, 104);
            this.nickelsTextBox.Name = "nickelsTextBox";
            this.nickelsTextBox.Size = new System.Drawing.Size(73, 20);
            this.nickelsTextBox.TabIndex = 4;
            // 
            // dimesTextBox
            // 
            this.dimesTextBox.Location = new System.Drawing.Point(114, 141);
            this.dimesTextBox.Name = "dimesTextBox";
            this.dimesTextBox.Size = new System.Drawing.Size(73, 20);
            this.dimesTextBox.TabIndex = 5;
            // 
            // quartersTextBox
            // 
            this.quartersTextBox.Location = new System.Drawing.Point(114, 178);
            this.quartersTextBox.Name = "quartersTextBox";
            this.quartersTextBox.Size = new System.Drawing.Size(73, 20);
            this.quartersTextBox.TabIndex = 6;
            // 
            // quartersLabel
            // 
            this.quartersLabel.AutoSize = true;
            this.quartersLabel.Location = new System.Drawing.Point(61, 181);
            this.quartersLabel.Name = "quartersLabel";
            this.quartersLabel.Size = new System.Drawing.Size(47, 13);
            this.quartersLabel.TabIndex = 7;
            this.quartersLabel.Text = "Quarters";
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(111, 31);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.instructionsLabel.Size = new System.Drawing.Size(273, 13);
            this.instructionsLabel.TabIndex = 8;
            this.instructionsLabel.Text = "Enter an amount of coins that total the given dollar value";
            // 
            // dollarLabel
            // 
            this.dollarLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dollarLabel.Location = new System.Drawing.Point(234, 104);
            this.dollarLabel.Name = "dollarLabel";
            this.dollarLabel.Size = new System.Drawing.Size(100, 23);
            this.dollarLabel.TabIndex = 9;
            this.dollarLabel.Text = "$1.00";
            this.dollarLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // submitAnswerButton
            // 
            this.submitAnswerButton.Location = new System.Drawing.Point(234, 144);
            this.submitAnswerButton.Name = "submitAnswerButton";
            this.submitAnswerButton.Size = new System.Drawing.Size(100, 23);
            this.submitAnswerButton.TabIndex = 10;
            this.submitAnswerButton.Text = "Submit";
            this.submitAnswerButton.UseVisualStyleBackColor = true;
            this.submitAnswerButton.Click += new System.EventHandler(this.submitAnswerButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(186, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 290);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitAnswerButton);
            this.Controls.Add(this.dollarLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.quartersLabel);
            this.Controls.Add(this.quartersTextBox);
            this.Controls.Add(this.dimesTextBox);
            this.Controls.Add(this.nickelsTextBox);
            this.Controls.Add(this.dimesLabel);
            this.Controls.Add(this.nickelsLabel);
            this.Controls.Add(this.penniesLabel);
            this.Controls.Add(this.penniesTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox penniesTextBox;
        private System.Windows.Forms.Label penniesLabel;
        private System.Windows.Forms.Label nickelsLabel;
        private System.Windows.Forms.Label dimesLabel;
        private System.Windows.Forms.TextBox nickelsTextBox;
        private System.Windows.Forms.TextBox dimesTextBox;
        private System.Windows.Forms.TextBox quartersTextBox;
        private System.Windows.Forms.Label quartersLabel;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label dollarLabel;
        private System.Windows.Forms.Button submitAnswerButton;
        private System.Windows.Forms.Button exitButton;
    }
}

