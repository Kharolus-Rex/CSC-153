﻿/* *
 * 1/13/23
 * CSC 153
 * Connor Naylor
 * This program is designed to test
 * the users ability to correctly reach
 * $1.00 by allowing them to input a number
 * of coins and calculating if they are correct
 * or not.
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void submitAnswerButton_Click(object sender, EventArgs e)
        {
            if (((double.Parse(penniesTextBox.Text) * 0.01) + (double.Parse(nickelsTextBox.Text) * 0.05) + (double.Parse(dimesTextBox.Text) * 0.10) + (double.Parse(quartersTextBox.Text) * 0.25)) == 1.00)
            {
                MessageBox.Show("That is correct!");
            }
            else
            {
                MessageBox.Show("Incorrect. Please adjust coins and try again.");
            }

        }

    }
}
