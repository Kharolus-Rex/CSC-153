﻿/**
 * 1/20/22
 * CSC 153
 * Connor Naylor
 * This program is designed to display various
 * format combinations for a given user's
 * Title, First name, Middle name, and Last name.
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class NameFormatWinForm : Form
    {
        public NameFormatWinForm()
        {
            InitializeComponent();
        }

        private void ReadInputButton_Click(object sender, EventArgs e)
        {
            /* Assign name and title inputs from user
            * to output label Text property with proper
            * format
            */

            // format Title First Name Middle Name Last Name
            outputLabelTFML.Text = titleTextBox.Text + " " + firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            // format First Name Middle Name Last Name
            outputLabelFML.Text = firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            // format First Name Last Name
            outputLabelFL.Text = firstNameTextBox.Text + " " + lastNameTextBox.Text;

            // format Last Name, First Name Middle Name, Title
            outputLabelLFMT.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text + ", " + titleTextBox.Text;

            // format Last Name, First Name Middle Name
            outputLabelLFM.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text;

            // format Last Name, First Name
            outputLabelLF.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
