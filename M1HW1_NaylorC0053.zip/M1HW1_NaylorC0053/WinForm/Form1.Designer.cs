﻿
namespace WinForm
{
    partial class NameFormatWinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.readInputButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputLabelTFML = new System.Windows.Forms.Label();
            this.outputLabelFML = new System.Windows.Forms.Label();
            this.outputLabelFL = new System.Windows.Forms.Label();
            this.outputLabelLFMT = new System.Windows.Forms.Label();
            this.outputLabelLFM = new System.Windows.Forms.Label();
            this.outputLabelLF = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(128, 12);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(134, 20);
            this.titleTextBox.TabIndex = 0;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(27, 15);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(73, 13);
            this.titleLabel.TabIndex = 1;
            this.titleLabel.Text = "Preferred Title";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(128, 39);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(134, 20);
            this.firstNameTextBox.TabIndex = 2;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(43, 42);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 3;
            this.firstNameLabel.Text = "First Name";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(391, 13);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(134, 20);
            this.middleNameTextBox.TabIndex = 4;
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(294, 16);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(69, 13);
            this.middleNameLabel.TabIndex = 5;
            this.middleNameLabel.Text = "Middle Name";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(391, 39);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(134, 20);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(306, 42);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 7;
            this.lastNameLabel.Text = "Last Name";
            // 
            // readInputButton
            // 
            this.readInputButton.Location = new System.Drawing.Point(46, 214);
            this.readInputButton.Name = "readInputButton";
            this.readInputButton.Size = new System.Drawing.Size(98, 33);
            this.readInputButton.TabIndex = 8;
            this.readInputButton.Text = "Read Input";
            this.readInputButton.UseVisualStyleBackColor = true;
            this.readInputButton.Click += new System.EventHandler(this.ReadInputButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(427, 214);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(98, 33);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputLabelTFML
            // 
            this.outputLabelTFML.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelTFML.Location = new System.Drawing.Point(46, 90);
            this.outputLabelTFML.Name = "outputLabelTFML";
            this.outputLabelTFML.Size = new System.Drawing.Size(216, 24);
            this.outputLabelTFML.TabIndex = 10;
            this.outputLabelTFML.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLabelFML
            // 
            this.outputLabelFML.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelFML.Location = new System.Drawing.Point(46, 124);
            this.outputLabelFML.Name = "outputLabelFML";
            this.outputLabelFML.Size = new System.Drawing.Size(216, 24);
            this.outputLabelFML.TabIndex = 11;
            this.outputLabelFML.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLabelFL
            // 
            this.outputLabelFL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelFL.Location = new System.Drawing.Point(46, 158);
            this.outputLabelFL.Name = "outputLabelFL";
            this.outputLabelFL.Size = new System.Drawing.Size(216, 24);
            this.outputLabelFL.TabIndex = 12;
            this.outputLabelFL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLabelLFMT
            // 
            this.outputLabelLFMT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelLFMT.Location = new System.Drawing.Point(309, 90);
            this.outputLabelLFMT.Name = "outputLabelLFMT";
            this.outputLabelLFMT.Size = new System.Drawing.Size(216, 24);
            this.outputLabelLFMT.TabIndex = 13;
            this.outputLabelLFMT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLabelLFM
            // 
            this.outputLabelLFM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelLFM.Location = new System.Drawing.Point(309, 124);
            this.outputLabelLFM.Name = "outputLabelLFM";
            this.outputLabelLFM.Size = new System.Drawing.Size(216, 24);
            this.outputLabelLFM.TabIndex = 14;
            this.outputLabelLFM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLabelLF
            // 
            this.outputLabelLF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabelLF.Location = new System.Drawing.Point(309, 158);
            this.outputLabelLF.Name = "outputLabelLF";
            this.outputLabelLF.Size = new System.Drawing.Size(216, 24);
            this.outputLabelLF.TabIndex = 15;
            this.outputLabelLF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NameFormatWinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 275);
            this.Controls.Add(this.outputLabelLF);
            this.Controls.Add(this.outputLabelLFM);
            this.Controls.Add(this.outputLabelLFMT);
            this.Controls.Add(this.outputLabelFL);
            this.Controls.Add(this.outputLabelFML);
            this.Controls.Add(this.outputLabelTFML);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.readInputButton);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.titleTextBox);
            this.Name = "NameFormatWinForm";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Button readInputButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label outputLabelTFML;
        private System.Windows.Forms.Label outputLabelFML;
        private System.Windows.Forms.Label outputLabelFL;
        private System.Windows.Forms.Label outputLabelLFMT;
        private System.Windows.Forms.Label outputLabelLFM;
        private System.Windows.Forms.Label outputLabelLF;
    }
}

