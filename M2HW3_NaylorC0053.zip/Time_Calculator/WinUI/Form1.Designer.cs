﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.secondsLabel = new System.Windows.Forms.Label();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.daysResultLabel = new System.Windows.Forms.Label();
            this.hoursResultLabel = new System.Windows.Forms.Label();
            this.minutesResultLabel = new System.Windows.Forms.Label();
            this.secondsResultLabel = new System.Windows.Forms.Label();
            this.secondsInputLabel = new System.Windows.Forms.Label();
            this.secondsInputTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(90, 90);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(37, 13);
            this.daysLabel.TabIndex = 0;
            this.daysLabel.Text = "Day(s)";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(86, 127);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(41, 13);
            this.hoursLabel.TabIndex = 1;
            this.hoursLabel.Text = "Hour(s)";
            // 
            // minutesLabel
            // 
            this.minutesLabel.AutoSize = true;
            this.minutesLabel.Location = new System.Drawing.Point(77, 166);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(50, 13);
            this.minutesLabel.TabIndex = 2;
            this.minutesLabel.Text = "Minute(s)";
            // 
            // secondsLabel
            // 
            this.secondsLabel.AutoSize = true;
            this.secondsLabel.Location = new System.Drawing.Point(72, 206);
            this.secondsLabel.Name = "secondsLabel";
            this.secondsLabel.Size = new System.Drawing.Size(55, 13);
            this.secondsLabel.TabIndex = 3;
            this.secondsLabel.Text = "Second(s)";
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(109, 47);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(252, 13);
            this.instructionsLabel.TabIndex = 8;
            this.instructionsLabel.Text = "Please input an amount of seconds to be calculated";
            // 
            // daysResultLabel
            // 
            this.daysResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.daysResultLabel.Location = new System.Drawing.Point(133, 85);
            this.daysResultLabel.Name = "daysResultLabel";
            this.daysResultLabel.Size = new System.Drawing.Size(100, 23);
            this.daysResultLabel.TabIndex = 9;
            this.daysResultLabel.Text = "0";
            this.daysResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursResultLabel
            // 
            this.hoursResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursResultLabel.Location = new System.Drawing.Point(133, 122);
            this.hoursResultLabel.Name = "hoursResultLabel";
            this.hoursResultLabel.Size = new System.Drawing.Size(100, 23);
            this.hoursResultLabel.TabIndex = 10;
            this.hoursResultLabel.Text = "0";
            this.hoursResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // minutesResultLabel
            // 
            this.minutesResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.minutesResultLabel.Location = new System.Drawing.Point(133, 161);
            this.minutesResultLabel.Name = "minutesResultLabel";
            this.minutesResultLabel.Size = new System.Drawing.Size(100, 23);
            this.minutesResultLabel.TabIndex = 11;
            this.minutesResultLabel.Text = "0";
            this.minutesResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secondsResultLabel
            // 
            this.secondsResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.secondsResultLabel.Location = new System.Drawing.Point(133, 201);
            this.secondsResultLabel.Name = "secondsResultLabel";
            this.secondsResultLabel.Size = new System.Drawing.Size(100, 23);
            this.secondsResultLabel.TabIndex = 12;
            this.secondsResultLabel.Text = "0";
            this.secondsResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secondsInputLabel
            // 
            this.secondsInputLabel.AutoSize = true;
            this.secondsInputLabel.Location = new System.Drawing.Point(283, 132);
            this.secondsInputLabel.Name = "secondsInputLabel";
            this.secondsInputLabel.Size = new System.Drawing.Size(108, 13);
            this.secondsInputLabel.TabIndex = 13;
            this.secondsInputLabel.Text = "Seconds to Calculate";
            // 
            // secondsInputTextBox
            // 
            this.secondsInputTextBox.Location = new System.Drawing.Point(286, 159);
            this.secondsInputTextBox.Name = "secondsInputTextBox";
            this.secondsInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.secondsInputTextBox.TabIndex = 14;
            this.secondsInputTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(297, 201);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 15;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(215, 261);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 340);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.secondsInputTextBox);
            this.Controls.Add(this.secondsInputLabel);
            this.Controls.Add(this.secondsResultLabel);
            this.Controls.Add(this.minutesResultLabel);
            this.Controls.Add(this.hoursResultLabel);
            this.Controls.Add(this.daysResultLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.secondsLabel);
            this.Controls.Add(this.minutesLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.daysLabel);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Time Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label secondsLabel;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label daysResultLabel;
        private System.Windows.Forms.Label hoursResultLabel;
        private System.Windows.Forms.Label minutesResultLabel;
        private System.Windows.Forms.Label secondsResultLabel;
        private System.Windows.Forms.Label secondsInputLabel;
        private System.Windows.Forms.TextBox secondsInputTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

