﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //define variable(s)
            int secondsTotal;

            //initialize to input value
            secondsTotal = int.Parse(secondsInputTextBox.Text);

            /*all result fields are defaulted to 0 to start with
            **let the math begin
            **using IF statement for each field. Allows some math to be skipped entirely
            */

            //days math
            if (secondsTotal >= 86400)
            {
                daysResultLabel.Text = (secondsTotal / 86400).ToString();              
            }

            //hours math
            if (secondsTotal >= 3600)
            {
                hoursResultLabel.Text = ((secondsTotal % 86400) / 3600).ToString();
            }

            //minutes math
            if (secondsTotal >= 60)
            {
                minutesResultLabel.Text = (((secondsTotal % 86400) % 3600) / 60).ToString();
            }

            //seconds remaining math
            if (secondsTotal >= 1)
            {
                secondsResultLabel.Text = (((secondsTotal % 86400) % 3600) % 60).ToString();
            }

        }
    }
}
