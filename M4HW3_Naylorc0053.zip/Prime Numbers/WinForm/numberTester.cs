﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    class numberTester
    {
        public static bool IsPrime(int numTest)
        {
            int prime; // will be set to 0 if false, 1 if true
            int testing = 9; // will be used in a for loop
            int accum = 0;

            for (int i = 1; i <= testing; ++i)
            {
                if (numTest % i == 0)
                {
                    accum++;
                }
            }

            if (accum == 2)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
