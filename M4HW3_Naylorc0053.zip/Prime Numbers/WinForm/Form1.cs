﻿/**
* 3/27/23
* CSC 153
* Connor Naylor
* This program tests a user input number to see if
* it is prime or not. Displays a message box with results.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            bool prime;
            int number = int.Parse(numberTextBox.Text);

            prime = numberTester.IsPrime(number);

            if (prime == true)
            {
                MessageBox.Show(number + " is a prime number.");
            }
            else
            {
                MessageBox.Show(number + " is not a prime number.");
            }
        }
    }
}
