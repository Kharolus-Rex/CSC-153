﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace ClassLibMain
{
    public class SlotMachine
    {
        public static int winnings = 0;

        public static int rollTrack = 0;

        public static string SlotRolling()
        {
            Random rnd = new Random();

            int seed1 = rnd.Next(20);
            int seed2 = rnd.Next(40);
            int seed3 = rnd.Next(60);
            
            List<string> fruits = new List<string> { "Apple.bmp", "Banana.bmp", "Cherries.bmp", "Grapes.bmp", "Lemon.bmp", "Lime.bmp", "Orange.bmp", "Pear.bmp", "Strawberry.bmp", "Watermelon.bmp" };

            int icon = rnd.Next(0, 10);

            return fruits[icon];

        }

        public static int WinningReturn(int bet, string A, string B, string C)
        {           
            if (A == B && B == C && A == C)
            {
                winnings += (bet * 3);
            }

            else if (A == B || B == C || A == C)
            {
                winnings += (bet * 2);
            }

            return winnings;
        }

    }
}
