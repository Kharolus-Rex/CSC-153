﻿/**
* 4/19/23
* CSC 153
* Connor Naylor
* This program will simulate a simple slot machine.
* It keeps track of your total spins and earnings and informs user
* on close what their earnings and total rolls were.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibMain;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //classlibmain method for showing running total
            MessageBox.Show("You earned $" + SlotMachine.winnings + " back after " + SlotMachine.rollTrack + " rolls.");

            this.Close();
        }

        private void betButton_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();

            string slot1 = SlotMachine.SlotRolling();

            slotOnePicBox.Image = Image.FromFile(slot1);

            string slot2 = SlotMachine.SlotRolling();

            slotTwoPicBox.Image = Image.FromFile(slot2);

            string slot3 = SlotMachine.SlotRolling();

            slotThreePicBox.Image = Image.FromFile(slot3);

            SlotMachine.WinningReturn((int.Parse(betTextBox.Text)), slot1, slot2, slot3);

            SlotMachine.rollTrack++;
        }
    }
}
