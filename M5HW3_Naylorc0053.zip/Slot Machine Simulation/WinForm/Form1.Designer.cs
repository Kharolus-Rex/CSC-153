﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.betButton = new System.Windows.Forms.Button();
            this.betTextBox = new System.Windows.Forms.TextBox();
            this.slotOnePicBox = new System.Windows.Forms.PictureBox();
            this.slotTwoPicBox = new System.Windows.Forms.PictureBox();
            this.slotThreePicBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.slotOnePicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotTwoPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotThreePicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(395, 332);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // betButton
            // 
            this.betButton.Location = new System.Drawing.Point(220, 332);
            this.betButton.Name = "betButton";
            this.betButton.Size = new System.Drawing.Size(75, 23);
            this.betButton.TabIndex = 1;
            this.betButton.Text = "Spin";
            this.betButton.UseVisualStyleBackColor = true;
            this.betButton.Click += new System.EventHandler(this.betButton_Click);
            // 
            // betTextBox
            // 
            this.betTextBox.Location = new System.Drawing.Point(294, 285);
            this.betTextBox.Name = "betTextBox";
            this.betTextBox.Size = new System.Drawing.Size(100, 20);
            this.betTextBox.TabIndex = 2;
            // 
            // slotOnePicBox
            // 
            this.slotOnePicBox.Location = new System.Drawing.Point(57, 62);
            this.slotOnePicBox.Name = "slotOnePicBox";
            this.slotOnePicBox.Size = new System.Drawing.Size(172, 163);
            this.slotOnePicBox.TabIndex = 3;
            this.slotOnePicBox.TabStop = false;
            // 
            // slotTwoPicBox
            // 
            this.slotTwoPicBox.Location = new System.Drawing.Point(256, 62);
            this.slotTwoPicBox.Name = "slotTwoPicBox";
            this.slotTwoPicBox.Size = new System.Drawing.Size(172, 163);
            this.slotTwoPicBox.TabIndex = 4;
            this.slotTwoPicBox.TabStop = false;
            // 
            // slotThreePicBox
            // 
            this.slotThreePicBox.Location = new System.Drawing.Point(451, 62);
            this.slotThreePicBox.Name = "slotThreePicBox";
            this.slotThreePicBox.Size = new System.Drawing.Size(172, 163);
            this.slotThreePicBox.TabIndex = 5;
            this.slotThreePicBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(253, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Insert bet here. Whole numbers only.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 402);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.slotThreePicBox);
            this.Controls.Add(this.slotTwoPicBox);
            this.Controls.Add(this.slotOnePicBox);
            this.Controls.Add(this.betTextBox);
            this.Controls.Add(this.betButton);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.slotOnePicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotTwoPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotThreePicBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button betButton;
        private System.Windows.Forms.TextBox betTextBox;
        private System.Windows.Forms.PictureBox slotOnePicBox;
        private System.Windows.Forms.PictureBox slotTwoPicBox;
        private System.Windows.Forms.PictureBox slotThreePicBox;
        private System.Windows.Forms.Label label1;
    }
}

