﻿
namespace WinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sqFtTextInput = new System.Windows.Forms.TextBox();
            this.sqFtLabel = new System.Windows.Forms.Label();
            this.formInstructions = new System.Windows.Forms.Label();
            this.costPerGallonLabel = new System.Windows.Forms.Label();
            this.costPerGallonText = new System.Windows.Forms.TextBox();
            this.hourlyLaborLabel = new System.Windows.Forms.Label();
            this.paintLaborPerSqFtLabel = new System.Windows.Forms.Label();
            this.calculateEstimateButton = new System.Windows.Forms.Button();
            this.exitFormButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sqFtTextInput
            // 
            this.sqFtTextInput.Location = new System.Drawing.Point(139, 41);
            this.sqFtTextInput.Name = "sqFtTextInput";
            this.sqFtTextInput.Size = new System.Drawing.Size(100, 20);
            this.sqFtTextInput.TabIndex = 0;
            // 
            // sqFtLabel
            // 
            this.sqFtLabel.Location = new System.Drawing.Point(33, 38);
            this.sqFtLabel.Name = "sqFtLabel";
            this.sqFtLabel.Size = new System.Drawing.Size(100, 23);
            this.sqFtLabel.TabIndex = 1;
            this.sqFtLabel.Text = "Sq Ft. of wall space";
            this.sqFtLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formInstructions
            // 
            this.formInstructions.Location = new System.Drawing.Point(33, 9);
            this.formInstructions.Name = "formInstructions";
            this.formInstructions.Size = new System.Drawing.Size(216, 23);
            this.formInstructions.TabIndex = 2;
            this.formInstructions.Text = "Please fill in the form to receive an estimate";
            this.formInstructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costPerGallonLabel
            // 
            this.costPerGallonLabel.AutoSize = true;
            this.costPerGallonLabel.Location = new System.Drawing.Point(19, 71);
            this.costPerGallonLabel.Name = "costPerGallonLabel";
            this.costPerGallonLabel.Size = new System.Drawing.Size(115, 13);
            this.costPerGallonLabel.TabIndex = 3;
            this.costPerGallonLabel.Text = "Cost per gallon of paint";
            this.costPerGallonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costPerGallonText
            // 
            this.costPerGallonText.Location = new System.Drawing.Point(140, 68);
            this.costPerGallonText.Name = "costPerGallonText";
            this.costPerGallonText.Size = new System.Drawing.Size(100, 20);
            this.costPerGallonText.TabIndex = 4;
            // 
            // hourlyLaborLabel
            // 
            this.hourlyLaborLabel.AutoSize = true;
            this.hourlyLaborLabel.Location = new System.Drawing.Point(91, 137);
            this.hourlyLaborLabel.Name = "hourlyLaborLabel";
            this.hourlyLaborLabel.Size = new System.Drawing.Size(91, 13);
            this.hourlyLaborLabel.TabIndex = 5;
            this.hourlyLaborLabel.Text = "Labor is $20/hour";
            this.hourlyLaborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paintLaborPerSqFtLabel
            // 
            this.paintLaborPerSqFtLabel.Location = new System.Drawing.Point(65, 91);
            this.paintLaborPerSqFtLabel.Name = "paintLaborPerSqFtLabel";
            this.paintLaborPerSqFtLabel.Size = new System.Drawing.Size(153, 46);
            this.paintLaborPerSqFtLabel.TabIndex = 6;
            this.paintLaborPerSqFtLabel.Text = "Every 115 sq ft will be 1 gallon of paint and 8 hours of labor";
            this.paintLaborPerSqFtLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateEstimateButton
            // 
            this.calculateEstimateButton.Location = new System.Drawing.Point(36, 170);
            this.calculateEstimateButton.Name = "calculateEstimateButton";
            this.calculateEstimateButton.Size = new System.Drawing.Size(75, 36);
            this.calculateEstimateButton.TabIndex = 7;
            this.calculateEstimateButton.Text = "Calculate Estimate";
            this.calculateEstimateButton.UseVisualStyleBackColor = true;
            this.calculateEstimateButton.Click += new System.EventHandler(this.calculateEstimateButton_Click);
            // 
            // exitFormButton
            // 
            this.exitFormButton.Location = new System.Drawing.Point(165, 170);
            this.exitFormButton.Name = "exitFormButton";
            this.exitFormButton.Size = new System.Drawing.Size(75, 36);
            this.exitFormButton.TabIndex = 8;
            this.exitFormButton.Text = "Exit";
            this.exitFormButton.UseVisualStyleBackColor = true;
            this.exitFormButton.Click += new System.EventHandler(this.exitFormButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 241);
            this.Controls.Add(this.exitFormButton);
            this.Controls.Add(this.calculateEstimateButton);
            this.Controls.Add(this.paintLaborPerSqFtLabel);
            this.Controls.Add(this.hourlyLaborLabel);
            this.Controls.Add(this.costPerGallonText);
            this.Controls.Add(this.costPerGallonLabel);
            this.Controls.Add(this.formInstructions);
            this.Controls.Add(this.sqFtLabel);
            this.Controls.Add(this.sqFtTextInput);
            this.Name = "Form1";
            this.Text = "Paint Job Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox sqFtTextInput;
        private System.Windows.Forms.Label sqFtLabel;
        private System.Windows.Forms.Label formInstructions;
        private System.Windows.Forms.Label costPerGallonLabel;
        private System.Windows.Forms.TextBox costPerGallonText;
        private System.Windows.Forms.Label hourlyLaborLabel;
        private System.Windows.Forms.Label paintLaborPerSqFtLabel;
        private System.Windows.Forms.Button calculateEstimateButton;
        private System.Windows.Forms.Button exitFormButton;
    }
}

