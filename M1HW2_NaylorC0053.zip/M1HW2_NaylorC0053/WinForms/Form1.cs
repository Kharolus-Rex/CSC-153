﻿/**
 * 1/25/22
 * CSC 153
 * Connor Naylor
 * This program is designed to calculate
 * the total cost of paint, labor, and overall
 * price of a paint job when given user input for
 * $/Gal paint and sq ft of wall space to be painted.
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateEstimateButton_Click(object sender, EventArgs e)
        {
            //initialize local variables for value storage
            double gallonsNeeded;
            int hoursNeeded;
            double totalLaborCost;
            double totalGalCost;
            double totalCost;

            //divide sqft by 115, round up. will be used in other calculations
            gallonsNeeded = Math.Ceiling(double.Parse(sqFtTextInput.Text) / 115);

            hoursNeeded = (int)(gallonsNeeded * 8);

            totalLaborCost = hoursNeeded * 20;

            totalGalCost = double.Parse(costPerGallonText.Text) * gallonsNeeded;

            totalCost = totalGalCost + totalLaborCost;

            //display estimate. gallons needed, hours needed, cost of paint, cost of labor, total cost.
            MessageBox.Show("Gallons required: " + gallonsNeeded + "\nHours of Labor: " + hoursNeeded + "\nTotal Cost of Paint: $" + totalGalCost + 
                "\nTotal Cost of Labor: $" + totalLaborCost + "\nTotal Job Cost: $" + totalCost);

        }

        private void exitFormButton_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
