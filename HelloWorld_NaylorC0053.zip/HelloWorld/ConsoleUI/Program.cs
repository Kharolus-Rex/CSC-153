﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("My name is Connor.");
            Console.WriteLine("I want to learn C# and add it to my list of known languages.");
            Console.WriteLine("I would also like to better understand how UI and code interacts.");
            Console.WriteLine("I have taken Java, C++ and Python basics");
            Console.WriteLine("While all of those calsses went over everything, it has been a while since Arrays or Lists were focused on.");
            Console.ReadLine();
        }
    }
}
