﻿/**
* 3/9/23
* CSC-153
* Connor Naylor
* A random number guessing game that also keeps track of
* attempts before finding the correct answer.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {

        //initiate and assign variable
        Random randNum = new Random();

        int answer;
        int guesses;

        public Form1()
        {
            InitializeComponent();

            generateNumber();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guessButton_Click(object sender, EventArgs e)
        {

            //define user variable
            int userGuess;

            //test time
            userGuess = int.Parse(guessTextBox.Text);

            guesses += 1;

            if (userGuess > answer)
            {
                MessageBox.Show("Too high, try again.");
            }
            else if (userGuess < answer)
            {
                MessageBox.Show("Too low, try again.");
            }
            else if (userGuess == answer)
            {
                MessageBox.Show("Congratulations! You are correct.\n It took you " + guesses + " guesses.\n Please close this box to start a new round.");
                generateNumber();
            }
        }

        private void generateNumber()
        {
            answer = randNum.Next(0, 101);
            guesses = 0;
        }
    }
}
