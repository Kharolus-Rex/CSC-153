﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.readerListBox = new System.Windows.Forms.ListBox();
            this.numberTotalLabel = new System.Windows.Forms.Label();
            this.numberTotalLabel2 = new System.Windows.Forms.Label();
            this.numberReadLabel = new System.Windows.Forms.Label();
            this.numberReadLabel2 = new System.Windows.Forms.Label();
            this.numberListLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.readFileButton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // readerListBox
            // 
            this.readerListBox.FormattingEnabled = true;
            this.readerListBox.Location = new System.Drawing.Point(72, 64);
            this.readerListBox.Name = "readerListBox";
            this.readerListBox.Size = new System.Drawing.Size(120, 160);
            this.readerListBox.TabIndex = 0;
            // 
            // numberTotalLabel
            // 
            this.numberTotalLabel.AutoSize = true;
            this.numberTotalLabel.Location = new System.Drawing.Point(76, 238);
            this.numberTotalLabel.Name = "numberTotalLabel";
            this.numberTotalLabel.Size = new System.Drawing.Size(86, 13);
            this.numberTotalLabel.TabIndex = 1;
            this.numberTotalLabel.Text = "Sum of numbers:";
            // 
            // numberTotalLabel2
            // 
            this.numberTotalLabel2.AutoSize = true;
            this.numberTotalLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberTotalLabel2.Location = new System.Drawing.Point(186, 238);
            this.numberTotalLabel2.Name = "numberTotalLabel2";
            this.numberTotalLabel2.Size = new System.Drawing.Size(2, 15);
            this.numberTotalLabel2.TabIndex = 2;
            // 
            // numberReadLabel
            // 
            this.numberReadLabel.AutoSize = true;
            this.numberReadLabel.Location = new System.Drawing.Point(39, 264);
            this.numberReadLabel.Name = "numberReadLabel";
            this.numberReadLabel.Size = new System.Drawing.Size(126, 13);
            this.numberReadLabel.TabIndex = 3;
            this.numberReadLabel.Text = "Number of numbers read:";
            // 
            // numberReadLabel2
            // 
            this.numberReadLabel2.AutoSize = true;
            this.numberReadLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberReadLabel2.Location = new System.Drawing.Point(186, 264);
            this.numberReadLabel2.Name = "numberReadLabel2";
            this.numberReadLabel2.Size = new System.Drawing.Size(2, 15);
            this.numberReadLabel2.TabIndex = 4;
            this.numberReadLabel2.Click += new System.EventHandler(this.numberReadLabel2_Click);
            // 
            // numberListLabel
            // 
            this.numberListLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberListLabel.Location = new System.Drawing.Point(83, 38);
            this.numberListLabel.Name = "numberListLabel";
            this.numberListLabel.Size = new System.Drawing.Size(100, 23);
            this.numberListLabel.TabIndex = 5;
            this.numberListLabel.Text = "List of Numbers";
            this.numberListLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 292);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // readFileButton
            // 
            this.readFileButton.Location = new System.Drawing.Point(38, 292);
            this.readFileButton.Name = "readFileButton";
            this.readFileButton.Size = new System.Drawing.Size(75, 23);
            this.readFileButton.TabIndex = 7;
            this.readFileButton.Text = "Read File";
            this.readFileButton.UseVisualStyleBackColor = true;
            this.readFileButton.Click += new System.EventHandler(this.readFileButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 356);
            this.Controls.Add(this.readFileButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numberListLabel);
            this.Controls.Add(this.numberReadLabel2);
            this.Controls.Add(this.numberReadLabel);
            this.Controls.Add(this.numberTotalLabel2);
            this.Controls.Add(this.numberTotalLabel);
            this.Controls.Add(this.readerListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox readerListBox;
        private System.Windows.Forms.Label numberTotalLabel;
        private System.Windows.Forms.Label numberTotalLabel2;
        private System.Windows.Forms.Label numberReadLabel;
        private System.Windows.Forms.Label numberReadLabel2;
        private System.Windows.Forms.Label numberListLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button readFileButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

