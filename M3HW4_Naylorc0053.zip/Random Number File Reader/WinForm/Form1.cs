﻿/**
* 3/13/23
* CSC 153
* Connor Naylor
* Program will gather name of file user opens
* and read all numbers from the file, keep track of how many are read, and their sum.
* Displays a list of all numbers read, the amount read, and the sum.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void readFileButton_Click(object sender, EventArgs e)
        {
            int number = 0; //current num val variable
            int sum = 0; //sum variable
            int accum = 0; //accumulator value for reader loop
            StreamReader readerFile;

            //open file and get file name
            openFileDialog1.ShowDialog();

            readerFile = File.OpenText(openFileDialog1.FileName);

            //clear list
            readerListBox.Items.Clear();

            while (!readerFile.EndOfStream)
            {
                number = int.Parse(readerFile.ReadLine());

                readerListBox.Items.Add(number); //add to list

                accum++; //accumulate

                sum += number; //continue sum
            }

            numberTotalLabel2.Text = sum.ToString(); //set sum label to sum

            numberReadLabel2.Text = accum.ToString(); //set to number of nums read

            //close file
            readerFile.Close();
        }

        private void numberReadLabel2_Click(object sender, EventArgs e)
        {

        }
    }
}
