﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    public class ConstructCall
    {
        //named ConstructCall due to using this later in 253
        //this will also contain the list of employees for now
        public static List<Employee> employees = new List<Employee>() { new Employee("Susan Meyers", int.Parse("47899"), "Accounting", "Vice President"), new Employee("Mark Jones", int.Parse("39119"), "IT", "Programmer"), new Employee("Joy Rogers", int.Parse("81774"), "Manufacturing", "Engineer") };

        public static List<string> LoadNames()
        {
            List<string> names = new List<string>();

            int i = 0;
            foreach (Employee employee in employees)
            {
                names.Add(employees[i].Name);
                i++;
            }

            return names;
        }

        public static List<string> LoadIDNums()
        {
            List<string> iDs = new List<string>();

            int i = 0;
            foreach (Employee employee in employees)
            {
                iDs.Add(employees[i].IdNumber.ToString());
                i++;
            }

            return iDs;
        }

        public static List<string> LoadDept()
        {
            List<string> department = new List<string>();

            int i = 0;
            foreach (Employee employee in employees)
            {
                department.Add(employees[i].Department);
                i++;
            }

            return department;
        }

        public static List<string> LoadTitle()
        {
            List<string> titles = new List<string>();

            int i = 0;
            foreach (Employee employee in employees)
            {
                titles.Add(employees[i].Position);
                i++;
            }

            return titles;
        }
    }
}
