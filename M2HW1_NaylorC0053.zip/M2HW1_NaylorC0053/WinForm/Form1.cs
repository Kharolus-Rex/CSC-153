﻿/**
 * 2/8/22
 * CSC 153
 * Connor Naylor
 * This program is a color mixer based upon
 * what radio buttons are active. The background will
 * change according to the color mix.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mixButton_Click(object sender, EventArgs e)
        {
            int colorPick = 0;

            if (((box1RedRadio.Checked == true) && (box2BlueRadio.Checked == true)) || ((box1BlueRadio.Checked == true) && (box2RedRadio.Checked == true)))
            {
                colorPick = 1;
            }
            else if (((box1RedRadio.Checked == true) && (box2YellowRadio.Checked == true)) || ((box1YellowRadio.Checked == true) && (box2RedRadio.Checked == true)))
            {
                colorPick = 2;
            }
            else if (((box1BlueRadio.Checked == true) && (box2YellowRadio.Checked == true)) || ((box1YellowRadio.Checked == true) && (box2BlueRadio.Checked == true)))
            {
                colorPick = 3;
            }
            else if ((box1RedRadio.Checked == true) && (box2RedRadio.Checked == true))
            {
                colorPick = 4;
            }
            else if ((box1BlueRadio.Checked == true) && (box2BlueRadio.Checked == true))
            {
                colorPick = 5;
            }
            else if ((box1YellowRadio.Checked == true) && (box2YellowRadio.Checked == true))
            {
                colorPick = 6;
            }

            switch (colorPick)
            {
                case 1:
                    this.BackColor = Color.Purple;
                    break;

                case 2:
                    this.BackColor = Color.Orange;
                    break;

                case 3:
                    this.BackColor = Color.Green;
                    break;

                case 4:
                    this.BackColor = Color.Red;
                    break;

                case 5:
                    this.BackColor = Color.Blue;
                    break;

                case 6:
                    this.BackColor = Color.Yellow;
                    break;
            }
        }
    }
}
