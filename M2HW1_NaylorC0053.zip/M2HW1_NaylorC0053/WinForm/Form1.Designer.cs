﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.box1YellowRadio = new System.Windows.Forms.RadioButton();
            this.box1BlueRadio = new System.Windows.Forms.RadioButton();
            this.box1RedRadio = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.box2YellowRadio = new System.Windows.Forms.RadioButton();
            this.box2BlueRadio = new System.Windows.Forms.RadioButton();
            this.box2RedRadio = new System.Windows.Forms.RadioButton();
            this.exitButton = new System.Windows.Forms.Button();
            this.mixButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.box1YellowRadio);
            this.groupBox1.Controls.Add(this.box1BlueRadio);
            this.groupBox1.Controls.Add(this.box1RedRadio);
            this.groupBox1.Location = new System.Drawing.Point(98, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(136, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select the First Color";
            // 
            // box1YellowRadio
            // 
            this.box1YellowRadio.AutoSize = true;
            this.box1YellowRadio.Location = new System.Drawing.Point(7, 68);
            this.box1YellowRadio.Name = "box1YellowRadio";
            this.box1YellowRadio.Size = new System.Drawing.Size(56, 17);
            this.box1YellowRadio.TabIndex = 2;
            this.box1YellowRadio.TabStop = true;
            this.box1YellowRadio.Text = "Yellow";
            this.box1YellowRadio.UseVisualStyleBackColor = true;
            // 
            // box1BlueRadio
            // 
            this.box1BlueRadio.AutoSize = true;
            this.box1BlueRadio.Location = new System.Drawing.Point(7, 44);
            this.box1BlueRadio.Name = "box1BlueRadio";
            this.box1BlueRadio.Size = new System.Drawing.Size(46, 17);
            this.box1BlueRadio.TabIndex = 1;
            this.box1BlueRadio.TabStop = true;
            this.box1BlueRadio.Text = "Blue";
            this.box1BlueRadio.UseVisualStyleBackColor = true;
            // 
            // box1RedRadio
            // 
            this.box1RedRadio.AutoSize = true;
            this.box1RedRadio.Location = new System.Drawing.Point(7, 20);
            this.box1RedRadio.Name = "box1RedRadio";
            this.box1RedRadio.Size = new System.Drawing.Size(45, 17);
            this.box1RedRadio.TabIndex = 0;
            this.box1RedRadio.TabStop = true;
            this.box1RedRadio.Text = "Red";
            this.box1RedRadio.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.box2YellowRadio);
            this.groupBox2.Controls.Add(this.box2BlueRadio);
            this.groupBox2.Controls.Add(this.box2RedRadio);
            this.groupBox2.Location = new System.Drawing.Point(293, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(136, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select the Second Color";
            // 
            // box2YellowRadio
            // 
            this.box2YellowRadio.AutoSize = true;
            this.box2YellowRadio.Location = new System.Drawing.Point(7, 68);
            this.box2YellowRadio.Name = "box2YellowRadio";
            this.box2YellowRadio.Size = new System.Drawing.Size(56, 17);
            this.box2YellowRadio.TabIndex = 2;
            this.box2YellowRadio.TabStop = true;
            this.box2YellowRadio.Text = "Yellow";
            this.box2YellowRadio.UseVisualStyleBackColor = true;
            // 
            // box2BlueRadio
            // 
            this.box2BlueRadio.AutoSize = true;
            this.box2BlueRadio.Location = new System.Drawing.Point(7, 44);
            this.box2BlueRadio.Name = "box2BlueRadio";
            this.box2BlueRadio.Size = new System.Drawing.Size(46, 17);
            this.box2BlueRadio.TabIndex = 1;
            this.box2BlueRadio.TabStop = true;
            this.box2BlueRadio.Text = "Blue";
            this.box2BlueRadio.UseVisualStyleBackColor = true;
            // 
            // box2RedRadio
            // 
            this.box2RedRadio.AutoSize = true;
            this.box2RedRadio.Location = new System.Drawing.Point(7, 20);
            this.box2RedRadio.Name = "box2RedRadio";
            this.box2RedRadio.Size = new System.Drawing.Size(45, 17);
            this.box2RedRadio.TabIndex = 0;
            this.box2RedRadio.TabStop = true;
            this.box2RedRadio.Text = "Red";
            this.box2RedRadio.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(293, 186);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // mixButton
            // 
            this.mixButton.Location = new System.Drawing.Point(159, 186);
            this.mixButton.Name = "mixButton";
            this.mixButton.Size = new System.Drawing.Size(75, 23);
            this.mixButton.TabIndex = 3;
            this.mixButton.Text = "Mix";
            this.mixButton.UseVisualStyleBackColor = true;
            this.mixButton.Click += new System.EventHandler(this.mixButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 255);
            this.Controls.Add(this.mixButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Color Mixer";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton box1YellowRadio;
        private System.Windows.Forms.RadioButton box1BlueRadio;
        private System.Windows.Forms.RadioButton box1RedRadio;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton box2YellowRadio;
        private System.Windows.Forms.RadioButton box2BlueRadio;
        private System.Windows.Forms.RadioButton box2RedRadio;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button mixButton;
    }
}

