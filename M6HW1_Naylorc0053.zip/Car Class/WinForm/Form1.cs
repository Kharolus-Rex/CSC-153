﻿/**
* 4/24/23
* CSC 153
* Connor Naylor
* This program demonstrates simple understanding of making classes and objects.
* The object created is stored in a list. Speed is updated in 2 ways, all fields are called upon exit.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarClass;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {

            MessageBox.Show($"Your {Methods.cars[0].Year} {Methods.cars[0].Make} was going {Methods.cars[0].Speed} MPH before closing the program.");

            this.Close();

        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            Methods.cars[0].Speed += 5; //increase speed before called

            speedChangingLabel.Text = (Methods.cars[0].Speed).ToString(); ;
        }

        private void createCarButton_Click(object sender, EventArgs e)
        {
            Methods.CreateCar(int.Parse(yearTextBox.Text), makeTextBox.Text);

            speedChangingLabel.Text = "0";
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {            
            if (Methods.cars[0].Speed !=0) //if statement so negative speeds are not displayed.
                {
                    Methods.cars[0].Speed -= 5; //decrease speed before called

                    speedChangingLabel.Text = (Methods.cars[0].Speed).ToString();
                }
        }
    }
}
