﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClass;

namespace CarClass
{
    public class Methods
    {
        
        public static List<Car> cars = new List<Car>();

        public static void CreateCar(int year, string make)
        {

            cars.Add(new Car(year, make, 0));

        }

    }
}
